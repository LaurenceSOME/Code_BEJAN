/**
 * @file    carte_sd.h
 * @brief   Journalisation CSV sur carte SD (bus SPI, systeme de fichiers FAT).
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#ifndef CARTE_SD_H
#define CARTE_SD_H

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Configuration de la carte SD et du fichier de mesures.
 */
typedef struct {
    int         hote_spi;        /**< Hote SPI (SPI2_HOST ou SPI3_HOST). */
    int         pin_sck;         /**< Broche horloge SPI. */
    int         pin_miso;        /**< Broche MISO. */
    int         pin_mosi;        /**< Broche MOSI. */
    int         pin_cs;          /**< Broche chip select. */
    uint32_t    frequence_khz;   /**< Frequence du bus SPI en kHz. */
    const char *point_montage;   /**< Point de montage VFS (ex. "/sdcard"). */
    const char *nom_fichier;     /**< Nom du fichier CSV (ex. "Mesure1.csv"). */
    const char *entete;          /**< Ligne d'entete ecrite a la creation du fichier. */
} carte_sd_config_t;

/**
 * @brief Initialise le bus SPI puis tente un premier montage de la carte.
 *
 * La configuration est memorisee : les chaines pointees doivent rester valides.
 *
 * @param cfg  Configuration.
 * @return ESP_OK si la carte est prete, code d'erreur sinon (nouvel essai via carte_sd_reessayer()).
 */
esp_err_t carte_sd_init(const carte_sd_config_t *cfg);

/**
 * @brief Demonte proprement la carte (si montee) puis tente un nouveau montage.
 *
 * @return ESP_OK si la carte est prete, code d'erreur sinon.
 */
esp_err_t carte_sd_reessayer(void);

/**
 * @brief Indique si la carte est montee et accessible en ecriture.
 *
 * @return true si la carte est prete.
 */
bool carte_sd_est_prete(void);

/**
 * @brief Ajoute une ligne au fichier CSV, fichier ferme apres chaque ecriture.
 *
 * En cas d'echec (carte retiree), la carte est marquee absente.
 *
 * @param ligne  Ligne sans fin de ligne ("\r\n" ajoute).
 * @return ESP_OK en cas de succes, ESP_ERR_INVALID_STATE si la carte est absente, ESP_FAIL sinon.
 */
esp_err_t carte_sd_ecrire_ligne(const char *ligne);

#ifdef __cplusplus
}
#endif

#endif /* CARTE_SD_H */
