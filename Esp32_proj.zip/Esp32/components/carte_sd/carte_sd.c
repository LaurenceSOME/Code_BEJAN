/**
 * @file    carte_sd.c
 * @brief   Implementation de la journalisation CSV sur carte SD.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "carte_sd.h"

#include <stdio.h>
#include <sys/stat.h>

#include "driver/sdspi_host.h"
#include "driver/spi_common.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"

#define CARTE_SD_TAILLE_CHEMIN 64

static const char *TAG = "CARTE_SD";

/* Composants IDF bavards en cas d'echec de montage : le module produit son propre message. */
static const char *const TAGS_IDF_MASQUES[] = {
    "vfs_fat_sdmmc", "sdmmc_common", "sdmmc_init", "sdmmc_sd", "sdspi_host", "sdspi_transaction",
};

static carte_sd_config_t s_cfg;
static sdmmc_card_t *s_carte;
static char s_chemin[CARTE_SD_TAILLE_CHEMIN];
static bool s_bus_pret;
static bool s_prete;

static esp_err_t initialiser_bus(void)
{
    if (s_bus_pret) {
        return ESP_OK;
    }
    const spi_bus_config_t cfg_bus = {
        .mosi_io_num     = s_cfg.pin_mosi,
        .miso_io_num     = s_cfg.pin_miso,
        .sclk_io_num     = s_cfg.pin_sck,
        .quadwp_io_num   = -1,
        .quadhd_io_num   = -1,
        .max_transfer_sz = 4000,
    };
    ESP_RETURN_ON_ERROR(spi_bus_initialize(s_cfg.hote_spi, &cfg_bus, SPI_DMA_CH_AUTO), TAG, "initialisation bus SPI");
    s_bus_pret = true;
    return ESP_OK;
}

static void demonter(void)
{
    if (s_carte) {
        esp_vfs_fat_sdcard_unmount(s_cfg.point_montage, s_carte);
        s_carte = NULL;
    }
    s_prete = false;
}

static esp_err_t creer_entete_si_absent(void)
{
    struct stat st;
    if (stat(s_chemin, &st) == 0) {
        return ESP_OK;
    }
    FILE *f = fopen(s_chemin, "w");
    ESP_RETURN_ON_FALSE(f, ESP_FAIL, TAG, "creation de %s impossible", s_chemin);
    fprintf(f, "%s\r\n", s_cfg.entete);
    fclose(f);
    ESP_LOGI(TAG, "Fichier %s cree avec entete", s_chemin);
    return ESP_OK;
}

static esp_err_t monter(void)
{
    ESP_RETURN_ON_ERROR(initialiser_bus(), TAG, "bus SPI indisponible");

    sdmmc_host_t hote = SDSPI_HOST_DEFAULT();
    hote.slot         = s_cfg.hote_spi;
    hote.max_freq_khz = s_cfg.frequence_khz;

    sdspi_device_config_t cfg_dev = SDSPI_DEVICE_CONFIG_DEFAULT();
    cfg_dev.gpio_cs = s_cfg.pin_cs;
    cfg_dev.host_id = s_cfg.hote_spi;

    const esp_vfs_fat_mount_config_t cfg_montage = {
        .format_if_mount_failed = false,
        .max_files              = 2,
        .allocation_unit_size   = 16 * 1024,
    };

    esp_err_t err = esp_vfs_fat_sdspi_mount(s_cfg.point_montage, &hote, &cfg_dev, &cfg_montage, &s_carte);
    if (err != ESP_OK) {
        s_carte = NULL;
        ESP_LOGW(TAG, "Carte SD absente ou illisible (%s)", esp_err_to_name(err));
        return err;
    }

    err = creer_entete_si_absent();
    if (err != ESP_OK) {
        demonter();
        return err;
    }

    s_prete = true;
    uint64_t taille_mo = (uint64_t)s_carte->csd.capacity * s_carte->csd.sector_size / (1024 * 1024);
    ESP_LOGI(TAG, "Carte SD prete : %s (%llu Mo), journal %s", s_carte->cid.name, (unsigned long long)taille_mo, s_chemin);
    return ESP_OK;
}

esp_err_t carte_sd_init(const carte_sd_config_t *cfg)
{
    ESP_RETURN_ON_FALSE(cfg && cfg->point_montage && cfg->nom_fichier && cfg->entete,
                        ESP_ERR_INVALID_ARG, TAG, "configuration invalide");
    s_cfg = *cfg;

    int n = snprintf(s_chemin, sizeof(s_chemin), "%s/%s", cfg->point_montage, cfg->nom_fichier);
    ESP_RETURN_ON_FALSE(n > 0 && n < (int)sizeof(s_chemin), ESP_ERR_INVALID_SIZE, TAG, "chemin trop long");

    for (size_t i = 0; i < sizeof(TAGS_IDF_MASQUES) / sizeof(TAGS_IDF_MASQUES[0]); i++) {
        esp_log_level_set(TAGS_IDF_MASQUES[i], ESP_LOG_NONE);
    }
    return monter();
}

esp_err_t carte_sd_reessayer(void)
{
    demonter();
    return monter();
}

bool carte_sd_est_prete(void)
{
    return s_prete;
}

esp_err_t carte_sd_ecrire_ligne(const char *ligne)
{
    if (!s_prete) {
        return ESP_ERR_INVALID_STATE;
    }

    FILE *f = fopen(s_chemin, "a");
    if (!f) {
        ESP_LOGW(TAG, "Carte SD retiree ou inaccessible");
        s_prete = false;
        return ESP_FAIL;
    }
    int ecrits = fprintf(f, "%s\r\n", ligne);
    int fermeture = fclose(f);
    if (ecrits < 0 || fermeture != 0) {
        ESP_LOGW(TAG, "Echec d'ecriture : carte marquee absente");
        s_prete = false;
        return ESP_FAIL;
    }
    return ESP_OK;
}
