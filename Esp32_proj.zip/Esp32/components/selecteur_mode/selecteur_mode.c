/**
 * @file    selecteur_mode.c
 * @brief   Implementation de la lecture de l'interrupteur de mode.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "selecteur_mode.h"
#include "esp_check.h"
#include "esp_log.h"

static const char *TAG = "MODE";

static gpio_num_t s_pin = GPIO_NUM_NC;

esp_err_t selecteur_mode_init(gpio_num_t pin)
{
    const gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << pin,
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_RETURN_ON_ERROR(gpio_config(&cfg), TAG, "configuration GPIO%d", pin);
    s_pin = pin;
    ESP_LOGI(TAG, "Interrupteur sur GPIO%d (GND = MANUEL)", pin);
    return ESP_OK;
}

mode_fonctionnement_t selecteur_mode_lire(void)
{
    return (gpio_get_level(s_pin) == 0) ? MODE_MANUEL : MODE_AUTOMATIQUE;
}

const char *selecteur_mode_texte(mode_fonctionnement_t mode)
{
    return (mode == MODE_MANUEL) ? "MANUEL" : "AUTOMATIQUE";
}
