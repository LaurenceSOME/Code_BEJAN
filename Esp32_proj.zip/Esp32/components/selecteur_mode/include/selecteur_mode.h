/**
 * @file    selecteur_mode.h
 * @brief   Lecture de l'interrupteur MANUEL / AUTOMATIQUE (entree avec pull-up).
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#ifndef SELECTEUR_MODE_H
#define SELECTEUR_MODE_H

#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Mode de fonctionnement du suiveur.
 */
typedef enum {
    MODE_AUTOMATIQUE = 0, /**< Entree au niveau haut (interrupteur ouvert). */
    MODE_MANUEL,          /**< Entree reliee a la masse. */
} mode_fonctionnement_t;

/**
 * @brief Configure la broche de l'interrupteur en entree avec pull-up interne.
 *
 * @param pin  GPIO de l'interrupteur.
 * @return ESP_OK en cas de succes, code d'erreur GPIO sinon.
 */
esp_err_t selecteur_mode_init(gpio_num_t pin);

/**
 * @brief Lit la position courante de l'interrupteur.
 *
 * @return MODE_MANUEL si l'entree est a la masse, MODE_AUTOMATIQUE sinon.
 */
mode_fonctionnement_t selecteur_mode_lire(void);

/**
 * @brief Convertit un mode en texte ("MANUEL" ou "AUTOMATIQUE").
 *
 * @param mode  Mode a convertir.
 * @return Chaine constante.
 */
const char *selecteur_mode_texte(mode_fonctionnement_t mode);

#ifdef __cplusplus
}
#endif

#endif /* SELECTEUR_MODE_H */
