/**
 * @file    capteurs.h
 * @brief   Acquisition ADC1 des 4 voies photosensibles et des 2 potentiometres.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#ifndef CAPTEURS_H
#define CAPTEURS_H

#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Valeur ADC brute maximale (resolution 12 bits). */
#define CAPTEURS_ADC_MAX 4095

/**
 * @brief Index des voies photosensibles.
 */
typedef enum {
    CAPTEUR_A1 = 0,
    CAPTEUR_A2,
    CAPTEUR_A3,
    CAPTEUR_A4,
    CAPTEURS_NB_VOIES,
} capteur_voie_t;

/**
 * @brief Index des potentiometres.
 */
typedef enum {
    CAPTEUR_POT1 = 0,
    CAPTEUR_POT2,
    CAPTEURS_NB_POTS,
} capteur_pot_t;

/**
 * @brief Configuration des entrees analogiques (broches ADC1 uniquement).
 */
typedef struct {
    int      gpio_voies[CAPTEURS_NB_VOIES]; /**< GPIO des voies A1 a A4. */
    int      gpio_pots[CAPTEURS_NB_POTS];   /**< GPIO des potentiometres. */
    uint32_t nb_echantillons;               /**< Nombre de lectures moyennees par voie. */
    uint32_t delai_echantillon_us;          /**< Pause entre deux lectures, en microsecondes. */
} capteurs_config_t;

/**
 * @brief Jeu de mesures complet.
 */
typedef struct {
    int voie[CAPTEURS_NB_VOIES];    /**< Moyenne brute de chaque voie (0 a 4095). */
    int e1;                         /**< Erreur A1 - A2 (unites ADC). */
    int e2;                         /**< Erreur A3 - A4 (unites ADC). */
    int pot[CAPTEURS_NB_POTS];      /**< Lecture brute de chaque potentiometre. */
    int pot_pct[CAPTEURS_NB_POTS];  /**< Position de chaque potentiometre en %. */
} capteurs_mesures_t;

/**
 * @brief Initialise l'unite ADC1 (12 bits, attenuation 12 dB) et toutes les voies.
 *
 * @param cfg  Configuration des entrees.
 * @return ESP_OK en cas de succes, ESP_ERR_INVALID_ARG si une broche n'est pas sur ADC1,
 *         code d'erreur du driver ADC sinon.
 */
esp_err_t capteurs_init(const capteurs_config_t *cfg);

/**
 * @brief Lit les 4 voies (moyenne de nb_echantillons lectures) et calcule e1 et e2.
 *
 * Fonction bloquante : duree ~ 4 x nb_echantillons x delai_echantillon_us.
 *
 * @param[out] mesures  Champs voie, e1 et e2 mis a jour.
 * @return ESP_OK en cas de succes, code d'erreur du driver ADC sinon.
 */
esp_err_t capteurs_lire_voies(capteurs_mesures_t *mesures);

/**
 * @brief Lit une fois chaque potentiometre et calcule sa position en %.
 *
 * @param[out] mesures  Champs pot et pot_pct mis a jour.
 * @return ESP_OK en cas de succes, code d'erreur du driver ADC sinon.
 */
esp_err_t capteurs_lire_pots(capteurs_mesures_t *mesures);

/**
 * @brief Lit une fois un potentiometre.
 *
 * @param      pot   Index du potentiometre.
 * @param[out] brut  Valeur ADC brute (0 a 4095).
 * @return ESP_OK en cas de succes, ESP_ERR_INVALID_ARG ou code d'erreur ADC sinon.
 */
esp_err_t capteurs_lire_pot(capteur_pot_t pot, int *brut);

/**
 * @brief Nom texte d'une voie ("A1" a "A4").
 *
 * @param voie  Index de la voie.
 * @return Chaine constante.
 */
const char *capteurs_nom_voie(capteur_voie_t voie);

#ifdef __cplusplus
}
#endif

#endif /* CAPTEURS_H */
