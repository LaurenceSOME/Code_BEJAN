/**
 * @file    capteurs.c
 * @brief   Implementation de l'acquisition ADC1.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "capteurs.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_rom_sys.h"

static const char *TAG = "CAPTEURS";

static const char *const NOMS_VOIES[CAPTEURS_NB_VOIES] = { "A1", "A2", "A3", "A4" };

static adc_oneshot_unit_handle_t s_adc;
static adc_channel_t s_canaux_voies[CAPTEURS_NB_VOIES];
static adc_channel_t s_canaux_pots[CAPTEURS_NB_POTS];
static capteurs_config_t s_cfg;

static esp_err_t configurer_canal(int gpio, adc_channel_t *canal)
{
    adc_unit_t unite;
    ESP_RETURN_ON_ERROR(adc_oneshot_io_to_channel(gpio, &unite, canal), TAG, "GPIO%d non analogique", gpio);
    ESP_RETURN_ON_FALSE(unite == ADC_UNIT_1, ESP_ERR_INVALID_ARG, TAG, "GPIO%d n'est pas sur ADC1", gpio);

    const adc_oneshot_chan_cfg_t cfg_canal = {
        .atten    = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_12,
    };
    return adc_oneshot_config_channel(s_adc, *canal, &cfg_canal);
}

static esp_err_t lire_moyenne(adc_channel_t canal, int *moyenne)
{
    int64_t somme = 0;
    int brut;

    for (uint32_t i = 0; i < s_cfg.nb_echantillons; i++) {
        ESP_RETURN_ON_ERROR(adc_oneshot_read(s_adc, canal, &brut), TAG, "lecture canal %d", canal);
        somme += brut;
        esp_rom_delay_us(s_cfg.delai_echantillon_us);
    }
    *moyenne = (int)(somme / s_cfg.nb_echantillons);
    return ESP_OK;
}

esp_err_t capteurs_init(const capteurs_config_t *cfg)
{
    ESP_RETURN_ON_FALSE(cfg && cfg->nb_echantillons > 0, ESP_ERR_INVALID_ARG, TAG, "configuration invalide");
    s_cfg = *cfg;

    const adc_oneshot_unit_init_cfg_t cfg_unite = { .unit_id = ADC_UNIT_1 };
    ESP_RETURN_ON_ERROR(adc_oneshot_new_unit(&cfg_unite, &s_adc), TAG, "creation unite ADC1");

    for (int i = 0; i < CAPTEURS_NB_VOIES; i++) {
        ESP_RETURN_ON_ERROR(configurer_canal(cfg->gpio_voies[i], &s_canaux_voies[i]), TAG, "voie %s", NOMS_VOIES[i]);
    }
    for (int i = 0; i < CAPTEURS_NB_POTS; i++) {
        ESP_RETURN_ON_ERROR(configurer_canal(cfg->gpio_pots[i], &s_canaux_pots[i]), TAG, "Pot%d", i + 1);
    }

    ESP_LOGI(TAG, "ADC1 pret : %d voies + %d pots, moyenne sur %lu echantillons",
             CAPTEURS_NB_VOIES, CAPTEURS_NB_POTS, (unsigned long)cfg->nb_echantillons);
    return ESP_OK;
}

esp_err_t capteurs_lire_voies(capteurs_mesures_t *mesures)
{
    ESP_RETURN_ON_FALSE(mesures, ESP_ERR_INVALID_ARG, TAG, "argument nul");

    for (int i = 0; i < CAPTEURS_NB_VOIES; i++) {
        ESP_RETURN_ON_ERROR(lire_moyenne(s_canaux_voies[i], &mesures->voie[i]), TAG, "voie %s", NOMS_VOIES[i]);
    }
    mesures->e1 = mesures->voie[CAPTEUR_A1] - mesures->voie[CAPTEUR_A2];
    mesures->e2 = mesures->voie[CAPTEUR_A3] - mesures->voie[CAPTEUR_A4];
    return ESP_OK;
}

esp_err_t capteurs_lire_pot(capteur_pot_t pot, int *brut)
{
    ESP_RETURN_ON_FALSE(pot < CAPTEURS_NB_POTS && brut, ESP_ERR_INVALID_ARG, TAG, "argument invalide");
    return adc_oneshot_read(s_adc, s_canaux_pots[pot], brut);
}

esp_err_t capteurs_lire_pots(capteurs_mesures_t *mesures)
{
    ESP_RETURN_ON_FALSE(mesures, ESP_ERR_INVALID_ARG, TAG, "argument nul");

    for (int i = 0; i < CAPTEURS_NB_POTS; i++) {
        ESP_RETURN_ON_ERROR(capteurs_lire_pot((capteur_pot_t)i, &mesures->pot[i]), TAG, "Pot%d", i + 1);
        mesures->pot_pct[i] = mesures->pot[i] * 100 / CAPTEURS_ADC_MAX;
    }
    return ESP_OK;
}

const char *capteurs_nom_voie(capteur_voie_t voie)
{
    return (voie < CAPTEURS_NB_VOIES) ? NOMS_VOIES[voie] : "?";
}
