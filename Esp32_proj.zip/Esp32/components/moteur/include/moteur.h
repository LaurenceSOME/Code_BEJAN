/**
 * @file    moteur.h
 * @brief   Pilote de moteur DC via pont en H L298N (sens par GPIO, vitesse par PWM LEDC).
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#ifndef MOTEUR_H
#define MOTEUR_H

#include <stdint.h>
#include "esp_err.h"
#include "driver/gpio.h"
#include "driver/ledc.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Etat de rotation d'un moteur.
 */
typedef enum {
    MOTEUR_STOP = 0, /**< Moteur arrete (IN_A = IN_B = 0, PWM = 0). */
    MOTEUR_SENS_1,   /**< IN_A = 0, IN_B = 1. */
    MOTEUR_SENS_2,   /**< IN_A = 1, IN_B = 0. */
} moteur_etat_t;

/**
 * @brief Configuration materielle d'un moteur.
 */
typedef struct {
    const char     *nom;      /**< Nom affiche dans les logs (ex. "COURONNE"). */
    gpio_num_t      pin_en;   /**< Broche ENA/ENB du L298N (sortie PWM). */
    gpio_num_t      pin_in_a; /**< Broche IN1/IN3 du L298N. */
    gpio_num_t      pin_in_b; /**< Broche IN2/IN4 du L298N. */
    ledc_channel_t  canal;    /**< Canal LEDC dedie a ce moteur. */
    ledc_timer_t    timer;    /**< Timer LEDC initialise par moteur_init_pwm(). */
} moteur_config_t;

/**
 * @brief Instance d'un moteur. Les champs sont geres par le module.
 */
typedef struct {
    moteur_config_t cfg;  /**< Copie de la configuration. */
    moteur_etat_t   etat; /**< Dernier etat applique. */
    uint32_t        duty; /**< Dernier rapport cyclique applique. */
} moteur_t;

/**
 * @brief Initialise le timer LEDC partage par les moteurs.
 *
 * @param timer       Timer LEDC a configurer.
 * @param freq_hz     Frequence PWM en Hz.
 * @param resolution  Resolution du rapport cyclique.
 * @return ESP_OK en cas de succes, code d'erreur LEDC sinon.
 */
esp_err_t moteur_init_pwm(ledc_timer_t timer, uint32_t freq_hz, ledc_timer_bit_t resolution);

/**
 * @brief Configure les broches et le canal PWM d'un moteur, puis l'arrete.
 *
 * @param[out] moteur  Instance a initialiser.
 * @param[in]  cfg     Configuration materielle.
 * @return ESP_OK en cas de succes, ESP_ERR_INVALID_ARG ou code d'erreur driver sinon.
 */
esp_err_t moteur_init(moteur_t *moteur, const moteur_config_t *cfg);

/**
 * @brief Fait tourner le moteur dans le sens demande.
 *
 * Un changement d'etat est trace dans les logs (tag "MOTEUR").
 *
 * @param moteur  Instance initialisee.
 * @param sens    MOTEUR_SENS_1 ou MOTEUR_SENS_2 (MOTEUR_STOP equivaut a moteur_arreter()).
 * @param duty    Rapport cyclique PWM (0 a 2^resolution - 1).
 * @return ESP_OK en cas de succes, code d'erreur driver sinon.
 */
esp_err_t moteur_tourner(moteur_t *moteur, moteur_etat_t sens, uint32_t duty);

/**
 * @brief Arrete le moteur (IN_A = IN_B = 0, PWM = 0).
 *
 * @param moteur  Instance initialisee.
 * @return ESP_OK en cas de succes, code d'erreur driver sinon.
 */
esp_err_t moteur_arreter(moteur_t *moteur);

/**
 * @brief Retourne le dernier etat applique au moteur.
 *
 * @param moteur  Instance initialisee.
 * @return Etat courant.
 */
moteur_etat_t moteur_lire_etat(const moteur_t *moteur);

/**
 * @brief Convertit un etat en texte ("STOP", "SENS_1", "SENS_2").
 *
 * @param etat  Etat a convertir.
 * @return Chaine constante.
 */
const char *moteur_etat_texte(moteur_etat_t etat);

#ifdef __cplusplus
}
#endif

#endif /* MOTEUR_H */
