/**
 * @file    moteur.c
 * @brief   Implementation du pilote de moteur L298N.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "moteur.h"
#include "esp_check.h"
#include "esp_log.h"

#define MOTEUR_MODE_LEDC LEDC_LOW_SPEED_MODE

static const char *TAG = "MOTEUR";

static esp_err_t appliquer(moteur_t *moteur, moteur_etat_t etat, uint32_t duty)
{
    const moteur_config_t *cfg = &moteur->cfg;
    int niveau_a = (etat == MOTEUR_SENS_2) ? 1 : 0;
    int niveau_b = (etat == MOTEUR_SENS_1) ? 1 : 0;

    ESP_RETURN_ON_ERROR(gpio_set_level(cfg->pin_in_a, niveau_a), TAG, "%s : IN_A", cfg->nom);
    ESP_RETURN_ON_ERROR(gpio_set_level(cfg->pin_in_b, niveau_b), TAG, "%s : IN_B", cfg->nom);
    ESP_RETURN_ON_ERROR(ledc_set_duty(MOTEUR_MODE_LEDC, cfg->canal, duty), TAG, "%s : duty", cfg->nom);
    ESP_RETURN_ON_ERROR(ledc_update_duty(MOTEUR_MODE_LEDC, cfg->canal), TAG, "%s : maj duty", cfg->nom);

    if (etat != moteur->etat || duty != moteur->duty) {
        ESP_LOGI(TAG, "%s -> %s (PWM %lu)", cfg->nom, moteur_etat_texte(etat), (unsigned long)duty);
    }
    moteur->etat = etat;
    moteur->duty = duty;
    return ESP_OK;
}

esp_err_t moteur_init_pwm(ledc_timer_t timer, uint32_t freq_hz, ledc_timer_bit_t resolution)
{
    const ledc_timer_config_t cfg_timer = {
        .speed_mode      = MOTEUR_MODE_LEDC,
        .duty_resolution = resolution,
        .timer_num       = timer,
        .freq_hz         = freq_hz,
        .clk_cfg         = LEDC_AUTO_CLK,
    };
    ESP_RETURN_ON_ERROR(ledc_timer_config(&cfg_timer), TAG, "configuration timer LEDC");
    ESP_LOGI(TAG, "PWM pret : %lu Hz, %d bits", (unsigned long)freq_hz, (int)resolution);
    return ESP_OK;
}

esp_err_t moteur_init(moteur_t *moteur, const moteur_config_t *cfg)
{
    ESP_RETURN_ON_FALSE(moteur && cfg, ESP_ERR_INVALID_ARG, TAG, "argument nul");

    moteur->cfg  = *cfg;
    moteur->etat = MOTEUR_STOP;
    moteur->duty = 0;

    const gpio_config_t cfg_gpio = {
        .pin_bit_mask = (1ULL << cfg->pin_in_a) | (1ULL << cfg->pin_in_b),
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };
    ESP_RETURN_ON_ERROR(gpio_config(&cfg_gpio), TAG, "%s : configuration GPIO", cfg->nom);

    const ledc_channel_config_t cfg_canal = {
        .gpio_num   = cfg->pin_en,
        .speed_mode = MOTEUR_MODE_LEDC,
        .channel    = cfg->canal,
        .timer_sel  = cfg->timer,
        .duty       = 0,
        .hpoint     = 0,
    };
    ESP_RETURN_ON_ERROR(ledc_channel_config(&cfg_canal), TAG, "%s : configuration canal LEDC", cfg->nom);

    ESP_RETURN_ON_ERROR(appliquer(moteur, MOTEUR_STOP, 0), TAG, "%s : arret initial", cfg->nom);
    ESP_LOGI(TAG, "%s pret (EN=%d, IN_A=%d, IN_B=%d)", cfg->nom, cfg->pin_en, cfg->pin_in_a, cfg->pin_in_b);
    return ESP_OK;
}

esp_err_t moteur_tourner(moteur_t *moteur, moteur_etat_t sens, uint32_t duty)
{
    if (sens == MOTEUR_STOP) {
        return moteur_arreter(moteur);
    }
    return appliquer(moteur, sens, duty);
}

esp_err_t moteur_arreter(moteur_t *moteur)
{
    return appliquer(moteur, MOTEUR_STOP, 0);
}

moteur_etat_t moteur_lire_etat(const moteur_t *moteur)
{
    return moteur->etat;
}

const char *moteur_etat_texte(moteur_etat_t etat)
{
    switch (etat) {
    case MOTEUR_SENS_1: return "SENS_1";
    case MOTEUR_SENS_2: return "SENS_2";
    default:            return "STOP";
    }
}
