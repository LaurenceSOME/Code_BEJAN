/**
 * @file    suiveur.h
 * @brief   Logique du suiveur solaire : pilotage manuel / automatique et journalisation.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#ifndef SUIVEUR_H
#define SUIVEUR_H

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Initialise les capteurs, les moteurs, l'interrupteur de mode et la carte SD.
 *
 * L'absence de carte SD n'est pas bloquante (nouvel essai periodique).
 *
 * @return ESP_OK en cas de succes, code d'erreur du premier peripherique en defaut sinon.
 */
esp_err_t suiveur_init(void);

/**
 * @brief Cree la tache de controle (boucle de pilotage, rapport periodique, reprise SD).
 *
 * @return ESP_OK en cas de succes, ESP_ERR_NO_MEM si la tache ne peut pas etre creee.
 */
esp_err_t suiveur_demarrer(void);

#ifdef __cplusplus
}
#endif

#endif /* SUIVEUR_H */
