/**
 * @file    main.c
 * @brief   Point d'entree du suiveur solaire ESP32 (ESP-IDF).
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "esp_log.h"
#include "suiveur.h"

static const char *TAG = "MAIN";

void app_main(void)
{
    ESP_LOGI(TAG, "=== Suiveur solaire - demarrage ===");

    esp_err_t err = suiveur_init();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Initialisation en echec (%s) : arret", esp_err_to_name(err));
        return;
    }
    ESP_ERROR_CHECK(suiveur_demarrer());
}
