/**
 * @file    suiveur.c
 * @brief   Implementation de la logique du suiveur solaire.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "suiveur.h"

#include "capteurs.h"
#include "carte_sd.h"
#include "config_app.h"
#include "esp_check.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "moteur.h"
#include "rapport.h"
#include "selecteur_mode.h"

#define US_PAR_MS 1000LL

static const char *TAG = "SUIVEUR";

static moteur_t s_couronne;
static moteur_t s_verin;
static mode_fonctionnement_t s_mode;

static moteur_etat_t sens_depuis_pot(int brut)
{
    if (brut <= CFG_SEUIL_POT_BAS) {
        return MOTEUR_SENS_1;
    }
    if (brut >= CFG_SEUIL_POT_HAUT) {
        return MOTEUR_SENS_2;
    }
    return MOTEUR_STOP;
}

static moteur_etat_t sens_depuis_erreur(int erreur, int tolerance)
{
    if (erreur < -tolerance) {
        return MOTEUR_SENS_2;
    }
    if (erreur > tolerance) {
        return MOTEUR_SENS_1;
    }
    return MOTEUR_STOP;
}

static void pilotage_manuel(void)
{
    int p1, p2;

    if (capteurs_lire_pot(CAPTEUR_POT1, &p1) == ESP_OK) {
        moteur_tourner(&s_couronne, sens_depuis_pot(p1), CFG_PWM_MANUEL_M1);
    }
    if (capteurs_lire_pot(CAPTEUR_POT2, &p2) == ESP_OK) {
        moteur_tourner(&s_verin, sens_depuis_pot(p2), CFG_PWM_MANUEL_M2);
    }
}

static void pilotage_automatique(void)
{
    capteurs_mesures_t m;

    if (capteurs_lire_voies(&m) != ESP_OK) {
        ESP_LOGE(TAG, "Lecture capteurs en echec : moteurs arretes");
        moteur_arreter(&s_couronne);
        moteur_arreter(&s_verin);
        return;
    }
    moteur_tourner(&s_couronne, sens_depuis_erreur(m.e1, CFG_TOLERANCE_M1), CFG_PWM_AUTO_M1);
    moteur_tourner(&s_verin, sens_depuis_erreur(m.e2, CFG_TOLERANCE_M2), CFG_PWM_AUTO_M2);
}

static void publier_rapport(void)
{
    rapport_donnees_t d = { 0 };

    if (capteurs_lire_voies(&d.mesures) != ESP_OK || capteurs_lire_pots(&d.mesures) != ESP_OK) {
        ESP_LOGE(TAG, "Mesures indisponibles : rapport ignore");
        return;
    }
    d.temps_dixiemes = (uint32_t)(esp_timer_get_time() / 100000);
    d.mode = s_mode;
    d.etat_m1 = moteur_lire_etat(&s_couronne);
    d.etat_m2 = moteur_lire_etat(&s_verin);
    d.sd_prete = carte_sd_est_prete();
    rapport_publier(&d);
}

static void mettre_a_jour_mode(void)
{
    mode_fonctionnement_t mode = selecteur_mode_lire();
    if (mode != s_mode) {
        ESP_LOGI(TAG, "Changement de mode : %s -> %s", selecteur_mode_texte(s_mode), selecteur_mode_texte(mode));
        s_mode = mode;
    }
}

static void tache_suiveur(void *arg)
{
    (void)arg;
    int64_t dernier_essai_sd = 0;
    int64_t dernier_rapport;

    publier_rapport();
    dernier_rapport = esp_timer_get_time();

    for (;;) {
        mettre_a_jour_mode();
        if (s_mode == MODE_MANUEL) {
            pilotage_manuel();
        } else {
            pilotage_automatique();
        }

        int64_t maintenant = esp_timer_get_time();

        if (!carte_sd_est_prete() && maintenant - dernier_essai_sd >= CFG_SD_PERIODE_ESSAI_MS * US_PAR_MS) {
            dernier_essai_sd = maintenant;
            carte_sd_reessayer();
        }
        if (maintenant - dernier_rapport >= CFG_PERIODE_RAPPORT_MS * US_PAR_MS) {
            dernier_rapport = maintenant;
            publier_rapport();
        }

        vTaskDelay(pdMS_TO_TICKS(CFG_PERIODE_BOUCLE_MS));
    }
}

esp_err_t suiveur_init(void)
{
    const capteurs_config_t cfg_capteurs = {
        .gpio_voies           = { CFG_GPIO_A1, CFG_GPIO_A2, CFG_GPIO_A3, CFG_GPIO_A4 },
        .gpio_pots            = { CFG_GPIO_POT1, CFG_GPIO_POT2 },
        .nb_echantillons      = CFG_NB_ECHANTILLONS,
        .delai_echantillon_us = CFG_DELAI_ECHANTILLON_US,
    };
    ESP_RETURN_ON_ERROR(capteurs_init(&cfg_capteurs), TAG, "capteurs");

    ESP_RETURN_ON_ERROR(moteur_init_pwm(CFG_PWM_TIMER, CFG_PWM_FREQ_HZ, CFG_PWM_RESOLUTION), TAG, "PWM");

    const moteur_config_t cfg_couronne = {
        .nom = "COURONNE/M1", .pin_en = CFG_GPIO_ENA, .pin_in_a = CFG_GPIO_IN1, .pin_in_b = CFG_GPIO_IN2,
        .canal = CFG_PWM_CANAL_M1, .timer = CFG_PWM_TIMER,
    };
    ESP_RETURN_ON_ERROR(moteur_init(&s_couronne, &cfg_couronne), TAG, "moteur couronne");

    const moteur_config_t cfg_verin = {
        .nom = "VERIN/M2", .pin_en = CFG_GPIO_ENB, .pin_in_a = CFG_GPIO_IN3, .pin_in_b = CFG_GPIO_IN4,
        .canal = CFG_PWM_CANAL_M2, .timer = CFG_PWM_TIMER,
    };
    ESP_RETURN_ON_ERROR(moteur_init(&s_verin, &cfg_verin), TAG, "moteur verin");

    ESP_RETURN_ON_ERROR(selecteur_mode_init(CFG_GPIO_MODE), TAG, "interrupteur de mode");
    s_mode = selecteur_mode_lire();
    ESP_LOGI(TAG, "Mode initial : %s", selecteur_mode_texte(s_mode));

    const carte_sd_config_t cfg_sd = {
        .hote_spi      = CFG_SD_HOTE_SPI,
        .pin_sck       = CFG_GPIO_SD_SCK,
        .pin_miso      = CFG_GPIO_SD_MISO,
        .pin_mosi      = CFG_GPIO_SD_MOSI,
        .pin_cs        = CFG_GPIO_SD_CS,
        .frequence_khz = CFG_SD_FREQ_KHZ,
        .point_montage = CFG_SD_POINT_MONTAGE,
        .nom_fichier   = CFG_SD_FICHIER,
        .entete        = rapport_entete_csv(),
    };
    if (carte_sd_init(&cfg_sd) != ESP_OK) {
        ESP_LOGW(TAG, "Demarrage sans carte SD : nouvel essai toutes les %d s", CFG_SD_PERIODE_ESSAI_MS / 1000);
    }
    return ESP_OK;
}

esp_err_t suiveur_demarrer(void)
{
    BaseType_t ok = xTaskCreate(tache_suiveur, "suiveur", CFG_PILE_TACHE_OCTETS, NULL, CFG_PRIORITE_TACHE, NULL);
    ESP_RETURN_ON_FALSE(ok == pdPASS, ESP_ERR_NO_MEM, TAG, "creation de la tache impossible");
    ESP_LOGI(TAG, "Tache de controle demarree");
    return ESP_OK;
}
