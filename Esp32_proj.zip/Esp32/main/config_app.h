/**
 * @file    config_app.h
 * @brief   Brochage et parametres de reglage du suiveur solaire.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 *
 * @details Moteur 1 = COURONNE (L298N ENA/IN1/IN2), pilote par e1 = A1 - A2.
 *          Moteur 2 = VERIN    (L298N ENB/IN3/IN4), pilote par e2 = A3 - A4.
 */

#ifndef CONFIG_APP_H
#define CONFIG_APP_H

#include "driver/ledc.h"
#include "driver/spi_common.h"

/** @name Voies photosensibles (ADC1) */
/** @{ */
#define CFG_GPIO_A1                 36
#define CFG_GPIO_A2                 39
#define CFG_GPIO_A3                 34
#define CFG_GPIO_A4                 35
#define CFG_NB_ECHANTILLONS         2000   /**< Lectures moyennees par voie. */
#define CFG_DELAI_ECHANTILLON_US    100
/** @} */

/** @name Potentiometres (ADC1) */
/** @{ */
#define CFG_GPIO_POT1               32
#define CFG_GPIO_POT2               33
#define CFG_SEUIL_POT_BAS           800    /**< En dessous : SENS_1. */
#define CFG_SEUIL_POT_HAUT          3200   /**< Au dessus : SENS_2. */
/** @} */

/** @name Interrupteur de mode */
/** @{ */
#define CFG_GPIO_MODE               4      /**< GND = MANUEL, ouvert = AUTOMATIQUE. */
/** @} */

/** @name L298N */
/** @{ */
#define CFG_GPIO_ENA                25
#define CFG_GPIO_IN1                26
#define CFG_GPIO_IN2                27
#define CFG_GPIO_ENB                13
#define CFG_GPIO_IN3                16
#define CFG_GPIO_IN4                17
/** @} */

/** @name PWM (LEDC) */
/** @{ */
#define CFG_PWM_FREQ_HZ             1000
#define CFG_PWM_RESOLUTION          LEDC_TIMER_8_BIT
#define CFG_PWM_TIMER               LEDC_TIMER_0
#define CFG_PWM_CANAL_M1            LEDC_CHANNEL_0
#define CFG_PWM_CANAL_M2            LEDC_CHANNEL_1
#define CFG_PWM_MANUEL_M1           180
#define CFG_PWM_MANUEL_M2           255
#define CFG_PWM_AUTO_M1             255    /**< Valeurs croisees reprises telles quelles du code Arduino. */
#define CFG_PWM_AUTO_M2             180
/** @} */

/** @name Regulation automatique (unites ADC brutes, 0 a 4095) */
/** @{ */
#define CFG_TOLERANCE_M1            5      /**< Zone morte sur e1. */
#define CFG_TOLERANCE_M2            5      /**< Zone morte sur e2. */
/** @} */

/** @name Carte SD (VSPI) */
/** @{ */
#define CFG_SD_HOTE_SPI             SPI3_HOST
#define CFG_GPIO_SD_SCK             18
#define CFG_GPIO_SD_MISO            19
#define CFG_GPIO_SD_MOSI            23
#define CFG_GPIO_SD_CS              5
#define CFG_SD_FREQ_KHZ             4000
#define CFG_SD_POINT_MONTAGE        "/sdcard"
#define CFG_SD_FICHIER              "Mesure1.csv"
#define CFG_SD_PERIODE_ESSAI_MS     5000   /**< Delai entre deux tentatives de montage. */
/** @} */

/** @name Cadencement */
/** @{ */
#define CFG_PERIODE_BOUCLE_MS       20
#define CFG_PERIODE_RAPPORT_MS      1000
#define CFG_PILE_TACHE_OCTETS       6144
#define CFG_PRIORITE_TACHE          5
/** @} */

#endif /* CONFIG_APP_H */
