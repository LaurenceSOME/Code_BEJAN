/**
 * @file    rapport.c
 * @brief   Implementation de la mise en forme des mesures.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#include "rapport.h"

#include <stdio.h>
#include "carte_sd.h"
#include "esp_log.h"

#define RAPPORT_TAILLE_LIGNE 192

static const char *TAG = "MESURE";

static const char ENTETE_CSV[] =
    "t_s;A1_brut;A2_brut;A3_brut;A4_brut;e1_A1-A2;e2_A3-A4;"
    "Pot1_brut;Pot1_pct;Pot2_brut;Pot2_pct;MODE;COURONNE_M1;VERIN_M2";

const char *rapport_entete_csv(void)
{
    return ENTETE_CSV;
}

void rapport_publier(const rapport_donnees_t *d)
{
    const capteurs_mesures_t *m = &d->mesures;
    unsigned long secondes = d->temps_dixiemes / 10;
    unsigned int dixieme = d->temps_dixiemes % 10;
    const char *mode = selecteur_mode_texte(d->mode);
    const char *etat_m1 = moteur_etat_texte(d->etat_m1);
    const char *etat_m2 = moteur_etat_texte(d->etat_m2);

    ESP_LOGI(TAG, "t=%lu,%u s | A1=%d | A2=%d | A3=%d | A4=%d | e1(A1-A2)=%d | e2(A3-A4)=%d",
             secondes, dixieme,
             m->voie[CAPTEUR_A1], m->voie[CAPTEUR_A2], m->voie[CAPTEUR_A3], m->voie[CAPTEUR_A4],
             m->e1, m->e2);
    ESP_LOGI(TAG, "Pot1=%d (%d %%) | Pot2=%d (%d %%) | MODE=%s | COURONNE/M1=%s | VERIN/M2=%s | SD=%s",
             m->pot[CAPTEUR_POT1], m->pot_pct[CAPTEUR_POT1],
             m->pot[CAPTEUR_POT2], m->pot_pct[CAPTEUR_POT2],
             mode, etat_m1, etat_m2, d->sd_prete ? "OK" : "ABSENTE");

    char ligne[RAPPORT_TAILLE_LIGNE];
    int n = snprintf(ligne, sizeof(ligne), "%lu,%u;%d;%d;%d;%d;%d;%d;%d;%d;%d;%d;%s;%s;%s",
                     secondes, dixieme,
                     m->voie[CAPTEUR_A1], m->voie[CAPTEUR_A2], m->voie[CAPTEUR_A3], m->voie[CAPTEUR_A4],
                     m->e1, m->e2,
                     m->pot[CAPTEUR_POT1], m->pot_pct[CAPTEUR_POT1],
                     m->pot[CAPTEUR_POT2], m->pot_pct[CAPTEUR_POT2],
                     mode, etat_m1, etat_m2);
    if (n < 0 || n >= (int)sizeof(ligne)) {
        ESP_LOGE(TAG, "Ligne CSV tronquee");
        return;
    }
    carte_sd_ecrire_ligne(ligne);
}
