/**
 * @file    rapport.h
 * @brief   Mise en forme des mesures : affichage console et ligne CSV.
 * @author  SOME Debora
 * @date    2026-10-17
 * @version 1.0.0
 */

#ifndef RAPPORT_H
#define RAPPORT_H

#include <stdbool.h>
#include <stdint.h>
#include "capteurs.h"
#include "moteur.h"
#include "selecteur_mode.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Instantane du systeme a publier.
 */
typedef struct {
    uint32_t              temps_dixiemes; /**< Temps depuis le demarrage, en dixiemes de seconde. */
    capteurs_mesures_t    mesures;        /**< Voies, erreurs et potentiometres. */
    mode_fonctionnement_t mode;           /**< Mode courant. */
    moteur_etat_t         etat_m1;        /**< Etat du moteur 1 (couronne). */
    moteur_etat_t         etat_m2;        /**< Etat du moteur 2 (verin). */
    bool                  sd_prete;       /**< Carte SD disponible. */
} rapport_donnees_t;

/**
 * @brief Ligne d'entete du fichier CSV (separateur ';').
 *
 * @return Chaine constante.
 */
const char *rapport_entete_csv(void);

/**
 * @brief Affiche l'instantane dans la console (tag "MESURE") et l'ajoute au fichier CSV.
 *
 * Format CSV : separateur ';', decimale ','.
 *
 * @param donnees  Instantane a publier.
 */
void rapport_publier(const rapport_donnees_t *donnees);

#ifdef __cplusplus
}
#endif

#endif /* RAPPORT_H */
